document.addEventListener("DOMContentLoaded", () => {
    hidLinkbool = true;
    hidLink.addEventListener("click", () => {
        if (hidLinkbool) {
            hidLinkbool = false;
            con.id = 'connecthover';
            connectLink.id = 'connectLinkhover';
            hidLink.id = 'hidLinkhover';
            imgs = document.querySelectorAll(".img");
            imgs.forEach(img => {
                img.classList.remove('img');
                img.classList.add('imghover');
            });

        } else {
            hidLinkbool = true;
            connecthover.id = 'con';
            connectLinkhover.id = 'connectLink';
            hidLinkhover.id = 'hidLink';
            imgs = document.querySelectorAll(".imghover");
            imgs.forEach(img => {
                img.classList.remove('imghover');
                img.classList.add('img');
            });
        }
    })
})